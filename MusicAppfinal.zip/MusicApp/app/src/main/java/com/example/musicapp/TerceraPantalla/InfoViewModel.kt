package com.example.musicapp.TerceraPantalla

import androidx.lifecycle.ViewModel

class InfoViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}