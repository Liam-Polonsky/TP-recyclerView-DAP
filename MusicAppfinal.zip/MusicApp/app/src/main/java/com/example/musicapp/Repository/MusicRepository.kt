package com.example.musicapp.Repository

import com.example.musicapp.Class.SongClass
class MusicRepository{


    private var songList : MutableList<SongClass> = mutableListOf()

    init{

        songList.add(SongClass("Hotel California","","De los Eagles creada en 1973"))
        songList.add(SongClass("Two minutes to midnight","","De  Iron Maiden crada en 1981",))
        songList.add(SongClass("Fire in Cairo","","De The Cure creada en 1967"))
        songList.add(SongClass("Sultans of Swing","","De los Dire Straits creada en 1966"))
        songList.add(SongClass("Back in Black","","De AC/DC creada en 1985"))
        songList.add(SongClass("Purple Haze","","De Jimi Hendrix creada en 1965"))
        songList.add(SongClass("Simphony of Destruction","","De Megadeath creada en 1984"))
        songList.add(SongClass("Dazed and Confuse","","De Led Zeppelin creada en 1970"))
        songList.add(SongClass("Comfortably Numbed","","De Pink Floyd creada en 1977"))
        songList.add(SongClass("Shine on you crazy diamond","","De Pink Floyd creada en 1978"))
        songList.add(SongClass("Time","","De Pink Floyd creada en 1978"))
        songList.add(SongClass("Master of Puppets","","De Metallica creada en 1982"))

    }
        fun getSongs () : MutableList<SongClass>{
            return songList

    }
}




