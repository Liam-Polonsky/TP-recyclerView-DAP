package com.example.musicapp.PrimerPantalla

import androidx.lifecycle.ViewModel
import com.example.musicapp.Class.UserClass

class LogInViewModel : ViewModel() {

    var users:MutableList<UserClass> = mutableListOf()
    // TODO: Implement the ViewModel
}