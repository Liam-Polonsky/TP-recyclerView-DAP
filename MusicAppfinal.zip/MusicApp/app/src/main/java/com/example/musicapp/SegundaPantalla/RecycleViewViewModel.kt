package com.example.musicapp.SegundaPantalla

import androidx.lifecycle.ViewModel
import com.example.musicapp.Class.SongClass

class RecycleViewViewModel : ViewModel() {
    lateinit var songName : String

    lateinit var songBand : String

    lateinit var songYear : String

   fun initializeSongYear() {
        // Inicializar la propiedad songYear aquí
        songYear = ""// NO ME DEJA SI NO, TENGO QUE INCIALIZARLA POR QUE ME SALE QUE TENGO ERROR SI NO

}
}