package com.example.musicapp.TerceraPantalla

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.musicapp.R
import com.example.musicapp.SegundaPantalla.RecycleViewViewModel

class Info : Fragment() {

    companion object {
        fun newInstance() = Info()
    }

    private lateinit var viewModel: InfoViewModel
    private lateinit var viewModelRecSong: RecycleViewViewModel
    private lateinit var v : View
    private lateinit var banda: TextView
    private lateinit var año: TextView



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        v = inflater.inflate(R.layout.fragment_info, container, false)
        año = v.findViewById((R.id.viewYear))
        banda = v.findViewById((R.id.viewBand))
        return v
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(requireActivity()).get(InfoViewModel::class.java)
        viewModelRecSong = ViewModelProvider(requireActivity()).get(RecycleViewViewModel::class.java)
        viewModelRecSong.initializeSongYear() // Llamar al método para inicializar la propiedad
      val year = viewModelRecSong.songYear // Acceder a la propiedad songYear
        // TODO: Use the ViewModel

         año.text =viewModelRecSong.songYear
        banda.text = viewModelRecSong.songBand

    }

}