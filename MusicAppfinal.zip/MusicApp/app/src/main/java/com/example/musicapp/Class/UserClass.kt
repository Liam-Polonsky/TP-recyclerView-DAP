package com.example.musicapp.Class

class UserClass (

    var name:String,
    var pswr:String


        ){

}